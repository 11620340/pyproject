# Airplane-wars-game
这是自己学习Python飞机大战的代码和素材
主要是自学Python，第一次成功将代码推送到GitHub仓库，有点小成就感，仅此记录一下。
